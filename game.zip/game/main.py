import pygame
import json
import random

pygame.init()

WIDTH, HEIGHT = 1200, 800
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Учебная игра в стиле Марио")


background_image = pygame.image.load('./pic/bg.png')
background_image = pygame.transform.scale(background_image, (WIDTH, HEIGHT))

coin_image = pygame.image.load('./pic/coin.png')
coin_image = pygame.transform.scale(coin_image, (50, 50))


welcome_image = pygame.image.load('./pic/wc.jpg')
welcome_image = pygame.transform.scale(welcome_image, (1200, 800))

menu_image = pygame.image.load('./pic/wall.jpg')
menu_image = pygame.transform.scale(menu_image,(1200,800))

with open('questions.json', 'r', encoding='utf-8') as file:
    questions = json.load(file)

random.shuffle(questions)
questions = questions[:5]

WHITE = (255, 255, 255)
BRICK = (164, 74, 34)

font_question = pygame.font.Font('./fonts/HarreeghPoppedCyrillic.ttf', 40)
font_input = pygame.font.Font('./fonts/HarreeghPoppedCyrillic.ttf', 40)
font_menu = pygame.font.Font('./fonts/HarreeghPoppedCyrillic.ttf', 60)
font_welcome = pygame.font.Font('./fonts/HarreeghPoppedCyrillic.ttf', 60)


def wrap_text(text, font, max_width):
    words = text.split(' ')
    lines = []
    current_line = ""

    for word in words:
        test_line = current_line + word + ' '
        if font.size(test_line)[0] <= max_width:
            current_line = test_line
        else:
            lines.append(current_line)
            current_line = word + ' '


    if current_line:
        lines.append(current_line)

    return lines

def draw_welcome_screen():
    screen.blit(welcome_image, (0, 0))
    welcome_text = font_welcome.render("Нажмите X, чтобы начать игру", True, BRICK)
    screen.blit(welcome_text, (WIDTH // 2 - welcome_text.get_width() // 2, HEIGHT // 2 - welcome_text.get_height() // 2))
    pygame.display.flip()

class QuizGame:
    def __init__(self):
        self.score = 0
        self.current_question = 0
        self.user_input = ""

    def load_question(self):
        if self.current_question < len(questions):
            return questions[self.current_question]
        else:
            return None

    def check_answer(self):
        correct_answer = questions[self.current_question]['answer'].lower()
        if self.user_input.lower() == correct_answer:
            self.score += 1
        self.current_question += 1
        self.user_input = ""


def draw_question(question, user_input, score):
    screen.blit(background_image, (0, 0))

    wrapped_question = wrap_text(question['question'], font_question, WIDTH - 100)


    for i, line in enumerate(wrapped_question):
        question_text = font_question.render(line, True, WHITE)
        screen.blit(question_text, (50, 50 + i * 50))

    input_text = font_input.render(user_input, True, BRICK)
    screen.blit(input_text, (50, 400))  # Поле для ввода ответа

    screen.blit(coin_image, (WIDTH - 125, 10))
    score_text = font_input.render(str(score), True, WHITE)
    screen.blit(score_text, (WIDTH - 50, 20))


def draw_menu(score):
    screen.blit(menu_image, (0, 0))
    menu_text = font_menu.render("Игра окончена!", True, WHITE)
    score_text = font_menu.render(f"Собрано монет: {score}", True, WHITE)
    continue_text = font_menu.render("Нажмите C, чтобы продолжить", True, WHITE)
    exit_text = font_menu.render("Нажмите Q, чтобы выйти", True, WHITE)

    screen.blit(menu_text, (WIDTH // 2 - menu_text.get_width() // 2, HEIGHT // 2 - 200))
    screen.blit(score_text, (WIDTH // 2 - score_text.get_width() // 2, HEIGHT // 2 - 100))
    screen.blit(continue_text, (WIDTH // 2 - continue_text.get_width() // 2, HEIGHT // 2 + 100))
    screen.blit(exit_text, (WIDTH // 2 - exit_text.get_width() // 2, HEIGHT // 2 ))

def main():
    global questions
    random.shuffle(questions)
    questions = questions[:5]

    draw_welcome_screen()
    waiting_for_start = True
    while waiting_for_start:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                waiting_for_start = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_x:
                    waiting_for_start = False

    game = QuizGame()

    running = True
    while running:
        question = game.load_question()
        if question is None:
            draw_menu(game.score)
            pygame.display.flip()
            while running:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        running = False
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_c:
                            main()
                            break
                        elif event.key == pygame.K_q:
                            running = False
            continue
        else:
            draw_question(question, game.user_input, game.score)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        game.check_answer()
                    elif event.key == pygame.K_BACKSPACE:
                        game.user_input = game.user_input[:-1]
                    else:
                        if len(game.user_input) < 30:
                            game.user_input += event.unicode

        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main()










